﻿// Tail Recursion 1: Product of a List
let rec productTailRecursion lst accumulator =
    match lst with
    | [] -> accumulator
    | head :: tail -> productTailRecursion tail (accumulator * head)

let numbers = [1; 2; 3; 4; 5]
printfn "Product of the list: %d" (productTailRecursion numbers 1)

// Tail Recursion 2: Product of Odd Numbers
let rec productOfOdds n accumulator =
    if n < 1 then accumulator
    else productOfOdds (n - 2) (accumulator * n)

printfn "Product of odd numbers from 11 to 1: %d" (productOfOdds 11 1)

// Using Map Function with a Collection
let names = [" Charles"; "Babbage  "; "  Von Neumann  "; "  Dennis Ritchie  "]
let trimmedNames = names |> List.map (fun name -> name.Trim())
printfn "Trimmed names: %A" trimmedNames

// Using Filter and Reduce with Numbers
let numbersList = [1 .. 700]
let multiplesOf35 = numbersList |> List.filter (fun x -> x % 35 = 0)
let sumOfMultiples = multiplesOf35 |> List.fold (+) 0
printfn "Sum of numbers that are multiples of 7 and 5: %d" sumOfMultiples

// Using Filter and Reduce with Strings
let moreNames = ["James"; "Robert"; "John"; "William"; "Michael"; "David"; "Richard"]
let filteredNames = moreNames |> List.filter (fun name -> name.ToUpper().Contains("I"))
let concatenatedNames = filteredNames |> List.fold (+) ""
printfn "Concatenated names with 'I': %s" concatenatedNames
